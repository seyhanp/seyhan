#!/bin/sh

export http_port="9000"

